<?php
 

        $conn = mysqli_connect("localhost", "root", "", "kurudhidb");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // Taking all 5 values from the form data(input)
        $name                   = $_POST["name"];
        $email                  = $_POST["email"];
        $BloodGroup             = $_POST["bloodGroupType"];
        $Gender                 = $_POST["genderType"];
        $Age                    = $_POST["age"];
        $ContactNumber          = $_POST["contactNumber"];
        $Address                = $_POST["address"];
        $Country                = $_POST["country"];
        $State                  = $_POST["state"];
        $City                   = $_POST["city"];
        $AlternativeNumber      = $_POST["AltcontactNumber"];
        $LastBloodDonatedDate   = $_POST["BloodDonateDate"];
        $Area                   = $_POST["Area"];
        $CheckStatus            = $_POST["statusCheck"];

         
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO tb_bdrf  VALUES ('$name' ,'$email' ',$BloodGroup' ,'$Gender' ,'$Age' ,'$ContactNumber' ,'$Address' ,'$Country' ,'$State' ,'$City' ,'$AlternativeNumber' ,'$LastBloodDonatedDate' ,'$Area' ,'$CheckStatus')";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";
 
            // echo nl2br("\n$first_name\n $last_name\n "
            //     . "$gender\n $address\n $email");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
        ?>